using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace zpp_aplikacja.Pages.View.Child
{
    public class ChildModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
