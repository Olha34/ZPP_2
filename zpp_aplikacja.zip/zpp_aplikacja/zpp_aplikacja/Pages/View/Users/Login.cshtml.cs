using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace zpp_aplikacja.Pages.View.Users
{
    public class LoginModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
