using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace zpp_aplikacja.Pages.View.Users
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
