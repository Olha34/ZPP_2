using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace zpp_aplikacja.Pages.View.Parent
{
    public class TaskModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
