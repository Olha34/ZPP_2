using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace zpp_aplikacja.Pages.View.Parent
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
