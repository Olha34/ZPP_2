using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace zpp_aplikacja.Views.Parent
{
    public class EditUsersModel : PageModel
    {
        
    }
}
