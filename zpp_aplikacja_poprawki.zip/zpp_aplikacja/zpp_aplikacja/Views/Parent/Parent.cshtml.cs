using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace zpp_aplikacja.Pages.View.Parent
{
    public class ParentModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
